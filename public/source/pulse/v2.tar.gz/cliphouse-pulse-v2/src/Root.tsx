import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Pulse} from './videos/pulse/Pulse';
import {pulseMeta as meta} from './videos/pulse/meta';
import {pulseSchema as schema} from './videos/pulse/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="pulse" component={Pulse} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
