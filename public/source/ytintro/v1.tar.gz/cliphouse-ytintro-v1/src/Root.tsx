import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Ytintro} from './videos/ytintro/Ytintro';
import {ytintroMeta as meta} from './videos/ytintro/meta';
import {ytintroSchema as schema} from './videos/ytintro/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="ytintro" component={Ytintro} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
