import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Comparison} from './videos/comparison/Comparison';
import {comparisonMeta as meta} from './videos/comparison/meta';
import {comparisonSchema as schema} from './videos/comparison/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="comparison" component={Comparison} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
