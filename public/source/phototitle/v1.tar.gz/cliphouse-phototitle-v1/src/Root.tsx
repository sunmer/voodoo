import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Phototitle} from './videos/phototitle/Phototitle';
import {phototitleMeta as meta} from './videos/phototitle/meta';
import {phototitleSchema as schema} from './videos/phototitle/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="phototitle" component={Phototitle} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
