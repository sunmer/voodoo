import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Pixel} from './videos/pixel/Pixel';
import {pixelMeta as meta} from './videos/pixel/meta';
import {pixelSchema as schema} from './videos/pixel/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="pixel" component={Pixel} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
