import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Turntable} from './videos/turntable/Turntable';
import {turntableMeta as meta} from './videos/turntable/meta';
import {turntableSchema as schema} from './videos/turntable/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="turntable" component={Turntable} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
