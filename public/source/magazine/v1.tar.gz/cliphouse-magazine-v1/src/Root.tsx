import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Magazine} from './videos/magazine/Magazine';
import {magazineMeta as meta} from './videos/magazine/meta';
import {magazineSchema as schema} from './videos/magazine/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="magazine" component={Magazine} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
