import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Bento} from './videos/bento/Bento';
import {bentoMeta as meta} from './videos/bento/meta';
import {bentoSchema as schema} from './videos/bento/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="bento" component={Bento} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
