import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Doodle} from './videos/doodle/Doodle';
import {doodleMeta as meta} from './videos/doodle/meta';
import {doodleSchema as schema} from './videos/doodle/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="doodle" component={Doodle} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
