import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Swiss} from './videos/swiss/Swiss';
import {swissMeta as meta} from './videos/swiss/meta';
import {swissSchema as schema} from './videos/swiss/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="swiss" component={Swiss} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
