import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Terminal} from './videos/terminal/Terminal';
import {terminalMeta as meta} from './videos/terminal/meta';
import {terminalSchema as schema} from './videos/terminal/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="terminal" component={Terminal} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
