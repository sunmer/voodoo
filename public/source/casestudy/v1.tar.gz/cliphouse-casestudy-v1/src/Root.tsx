import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Casestudy} from './videos/casestudy/Casestudy';
import {casestudyMeta as meta} from './videos/casestudy/meta';
import {casestudySchema as schema} from './videos/casestudy/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="casestudy" component={Casestudy} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
