import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Thankyou} from './videos/thankyou/Thankyou';
import {thankyouMeta as meta} from './videos/thankyou/meta';
import {thankyouSchema as schema} from './videos/thankyou/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="thankyou" component={Thankyou} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
