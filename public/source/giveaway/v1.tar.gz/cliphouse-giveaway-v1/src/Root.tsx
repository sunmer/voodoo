import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Giveaway} from './videos/giveaway/Giveaway';
import {giveawayMeta as meta} from './videos/giveaway/meta';
import {giveawaySchema as schema} from './videos/giveaway/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="giveaway" component={Giveaway} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
