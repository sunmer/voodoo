import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Credits} from './videos/credits/Credits';
import {creditsMeta as meta} from './videos/credits/meta';
import {creditsSchema as schema} from './videos/credits/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="credits" component={Credits} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
