import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Webinar} from './videos/webinar/Webinar';
import {webinarMeta as meta} from './videos/webinar/meta';
import {webinarSchema as schema} from './videos/webinar/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="webinar" component={Webinar} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
