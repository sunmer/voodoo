import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Collage} from './videos/collage/Collage';
import {collageMeta as meta} from './videos/collage/meta';
import {collageSchema as schema} from './videos/collage/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="collage" component={Collage} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
