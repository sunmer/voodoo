import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Valentines} from './videos/valentines/Valentines';
import {valentinesMeta as meta} from './videos/valentines/meta';
import {valentinesSchema as schema} from './videos/valentines/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="valentines" component={Valentines} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
