import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Partnership} from './videos/partnership/Partnership';
import {partnershipMeta as meta} from './videos/partnership/meta';
import {partnershipSchema as schema} from './videos/partnership/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="partnership" component={Partnership} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
