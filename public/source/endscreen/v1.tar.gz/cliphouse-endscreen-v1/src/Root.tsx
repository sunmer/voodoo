import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Endscreen} from './videos/endscreen/Endscreen';
import {endscreenMeta as meta} from './videos/endscreen/meta';
import {endscreenSchema as schema} from './videos/endscreen/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="endscreen" component={Endscreen} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
