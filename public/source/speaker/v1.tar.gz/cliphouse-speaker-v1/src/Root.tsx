import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Speaker} from './videos/speaker/Speaker';
import {speakerMeta as meta} from './videos/speaker/meta';
import {speakerSchema as schema} from './videos/speaker/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="speaker" component={Speaker} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
