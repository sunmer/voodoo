import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Countdown} from './videos/countdown/Countdown';
import {countdownMeta as meta} from './videos/countdown/meta';
import {countdownSchema as schema} from './videos/countdown/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="countdown" component={Countdown} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
