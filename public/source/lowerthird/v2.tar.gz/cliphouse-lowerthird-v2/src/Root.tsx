import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Lowerthird} from './videos/lowerthird/Lowerthird';
import {lowerthirdMeta as meta} from './videos/lowerthird/meta';
import {lowerthirdSchema as schema} from './videos/lowerthird/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="lowerthird" component={Lowerthird} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
