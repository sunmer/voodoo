import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Orbit3d} from './videos/orbit3d/Orbit3d';
import {orbit3dMeta as meta} from './videos/orbit3d/meta';
import {orbit3dSchema as schema} from './videos/orbit3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="orbit3d" component={Orbit3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
