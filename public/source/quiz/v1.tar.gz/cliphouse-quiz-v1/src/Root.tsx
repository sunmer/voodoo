import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Quiz} from './videos/quiz/Quiz';
import {quizMeta as meta} from './videos/quiz/meta';
import {quizSchema as schema} from './videos/quiz/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="quiz" component={Quiz} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
