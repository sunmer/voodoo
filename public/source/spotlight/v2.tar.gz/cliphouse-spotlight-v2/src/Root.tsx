import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Spotlight} from './videos/spotlight/Spotlight';
import {spotlightMeta as meta} from './videos/spotlight/meta';
import {spotlightSchema as schema} from './videos/spotlight/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="spotlight" component={Spotlight} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
