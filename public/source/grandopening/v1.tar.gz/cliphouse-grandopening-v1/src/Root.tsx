import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Grandopening} from './videos/grandopening/Grandopening';
import {grandopeningMeta as meta} from './videos/grandopening/meta';
import {grandopeningSchema as schema} from './videos/grandopening/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="grandopening" component={Grandopening} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
