import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Travelintro} from './videos/travelintro/Travelintro';
import {travelintroMeta as meta} from './videos/travelintro/meta';
import {travelintroSchema as schema} from './videos/travelintro/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="travelintro" component={Travelintro} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
