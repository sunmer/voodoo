import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Podcast} from './videos/podcast/Podcast';
import {podcastMeta as meta} from './videos/podcast/meta';
import {podcastSchema as schema} from './videos/podcast/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="podcast" component={Podcast} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
