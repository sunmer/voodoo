import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Slideshow} from './videos/slideshow/Slideshow';
import {slideshowMeta as meta} from './videos/slideshow/meta';
import {slideshowSchema as schema} from './videos/slideshow/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="slideshow" component={Slideshow} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
