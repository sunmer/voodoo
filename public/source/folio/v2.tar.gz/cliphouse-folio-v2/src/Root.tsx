import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Folio} from './videos/folio/Folio';
import {folioMeta as meta} from './videos/folio/meta';
import {folioSchema as schema} from './videos/folio/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="folio" component={Folio} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
