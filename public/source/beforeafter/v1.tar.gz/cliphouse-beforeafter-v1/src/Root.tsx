import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Beforeafter} from './videos/beforeafter/Beforeafter';
import {beforeafterMeta as meta} from './videos/beforeafter/meta';
import {beforeafterSchema as schema} from './videos/beforeafter/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="beforeafter" component={Beforeafter} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
