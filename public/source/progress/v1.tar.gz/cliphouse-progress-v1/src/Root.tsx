import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Progress} from './videos/progress/Progress';
import {progressMeta as meta} from './videos/progress/meta';
import {progressSchema as schema} from './videos/progress/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="progress" component={Progress} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
