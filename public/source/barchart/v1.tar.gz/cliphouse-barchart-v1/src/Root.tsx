import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Barchart} from './videos/barchart/Barchart';
import {barchartMeta as meta} from './videos/barchart/meta';
import {barchartSchema as schema} from './videos/barchart/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="barchart" component={Barchart} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
