import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Countdown3d} from './videos/countdown3d/Countdown3d';
import {countdown3dMeta as meta} from './videos/countdown3d/meta';
import {countdown3dSchema as schema} from './videos/countdown3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="countdown3d" component={Countdown3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
