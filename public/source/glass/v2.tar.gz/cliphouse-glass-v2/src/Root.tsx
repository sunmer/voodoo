import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Glass} from './videos/glass/Glass';
import {glassMeta as meta} from './videos/glass/meta';
import {glassSchema as schema} from './videos/glass/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="glass" component={Glass} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
