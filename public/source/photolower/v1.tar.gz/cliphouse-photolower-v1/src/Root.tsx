import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Photolower} from './videos/photolower/Photolower';
import {photolowerMeta as meta} from './videos/photolower/meta';
import {photolowerSchema as schema} from './videos/photolower/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="photolower" component={Photolower} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
