import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Liquid} from './videos/liquid/Liquid';
import {liquidMeta as meta} from './videos/liquid/meta';
import {liquidSchema as schema} from './videos/liquid/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="liquid" component={Liquid} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
