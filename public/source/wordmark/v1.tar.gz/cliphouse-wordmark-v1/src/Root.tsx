import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Wordmark} from './videos/wordmark/Wordmark';
import {wordmarkMeta as meta} from './videos/wordmark/meta';
import {wordmarkSchema as schema} from './videos/wordmark/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="wordmark" component={Wordmark} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
