import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Riso} from './videos/riso/Riso';
import {risoMeta as meta} from './videos/riso/meta';
import {risoSchema as schema} from './videos/riso/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="riso" component={Riso} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
