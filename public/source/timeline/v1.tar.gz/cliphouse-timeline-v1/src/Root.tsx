import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Timeline} from './videos/timeline/Timeline';
import {timelineMeta as meta} from './videos/timeline/meta';
import {timelineSchema as schema} from './videos/timeline/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="timeline" component={Timeline} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
