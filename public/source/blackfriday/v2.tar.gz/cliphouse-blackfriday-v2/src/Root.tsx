import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Blackfriday} from './videos/blackfriday/Blackfriday';
import {blackfridayMeta as meta} from './videos/blackfriday/meta';
import {blackfridaySchema as schema} from './videos/blackfriday/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="blackfriday" component={Blackfriday} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
