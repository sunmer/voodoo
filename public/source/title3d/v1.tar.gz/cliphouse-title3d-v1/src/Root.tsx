import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Title3d} from './videos/title3d/Title3d';
import {title3dMeta as meta} from './videos/title3d/meta';
import {title3dSchema as schema} from './videos/title3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="title3d" component={Title3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
