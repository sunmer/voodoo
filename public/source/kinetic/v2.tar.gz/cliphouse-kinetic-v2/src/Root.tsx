import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Kinetic} from './videos/kinetic/Kinetic';
import {kineticMeta as meta} from './videos/kinetic/meta';
import {kineticSchema as schema} from './videos/kinetic/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="kinetic" component={Kinetic} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
