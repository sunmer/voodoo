import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Livestream} from './videos/livestream/Livestream';
import {livestreamMeta as meta} from './videos/livestream/meta';
import {livestreamSchema as schema} from './videos/livestream/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="livestream" component={Livestream} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
