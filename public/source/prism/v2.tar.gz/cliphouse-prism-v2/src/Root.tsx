import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Prism} from './videos/prism/Prism';
import {prismMeta as meta} from './videos/prism/meta';
import {prismSchema as schema} from './videos/prism/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="prism" component={Prism} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
