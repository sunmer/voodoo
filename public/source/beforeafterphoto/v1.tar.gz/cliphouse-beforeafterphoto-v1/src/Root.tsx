import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Beforeafterphoto} from './videos/beforeafterphoto/Beforeafterphoto';
import {beforeafterphotoMeta as meta} from './videos/beforeafterphoto/meta';
import {beforeafterphotoSchema as schema} from './videos/beforeafterphoto/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="beforeafterphoto" component={Beforeafterphoto} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
