import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Cursor} from './videos/cursor/Cursor';
import {cursorMeta as meta} from './videos/cursor/meta';
import {cursorSchema as schema} from './videos/cursor/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="cursor" component={Cursor} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
