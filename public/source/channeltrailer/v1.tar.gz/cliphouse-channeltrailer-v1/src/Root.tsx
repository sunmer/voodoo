import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Channeltrailer} from './videos/channeltrailer/Channeltrailer';
import {channeltrailerMeta as meta} from './videos/channeltrailer/meta';
import {channeltrailerSchema as schema} from './videos/channeltrailer/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="channeltrailer" component={Channeltrailer} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
