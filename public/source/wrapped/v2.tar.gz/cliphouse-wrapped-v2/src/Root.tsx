import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Wrapped} from './videos/wrapped/Wrapped';
import {wrappedMeta as meta} from './videos/wrapped/meta';
import {wrappedSchema as schema} from './videos/wrapped/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="wrapped" component={Wrapped} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
