import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Counter} from './videos/counter/Counter';
import {counterMeta as meta} from './videos/counter/meta';
import {counterSchema as schema} from './videos/counter/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="counter" component={Counter} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
