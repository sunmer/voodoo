import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Glitch} from './videos/glitch/Glitch';
import {glitchMeta as meta} from './videos/glitch/meta';
import {glitchSchema as schema} from './videos/glitch/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="glitch" component={Glitch} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
