import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Apppromo} from './videos/apppromo/Apppromo';
import {apppromoMeta as meta} from './videos/apppromo/meta';
import {apppromoSchema as schema} from './videos/apppromo/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="apppromo" component={Apppromo} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
