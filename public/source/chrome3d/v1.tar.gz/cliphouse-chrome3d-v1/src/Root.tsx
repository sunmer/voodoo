import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Chrome3d} from './videos/chrome3d/Chrome3d';
import {chrome3dMeta as meta} from './videos/chrome3d/meta';
import {chrome3dSchema as schema} from './videos/chrome3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="chrome3d" component={Chrome3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
