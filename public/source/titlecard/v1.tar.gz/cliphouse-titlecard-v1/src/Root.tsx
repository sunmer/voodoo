import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Titlecard} from './videos/titlecard/Titlecard';
import {titlecardMeta as meta} from './videos/titlecard/meta';
import {titlecardSchema as schema} from './videos/titlecard/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="titlecard" component={Titlecard} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
