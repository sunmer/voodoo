import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Linechart} from './videos/linechart/Linechart';
import {linechartMeta as meta} from './videos/linechart/meta';
import {linechartSchema as schema} from './videos/linechart/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="linechart" component={Linechart} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
