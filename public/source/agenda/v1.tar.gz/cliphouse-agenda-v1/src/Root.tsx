import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Agenda} from './videos/agenda/Agenda';
import {agendaMeta as meta} from './videos/agenda/meta';
import {agendaSchema as schema} from './videos/agenda/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="agenda" component={Agenda} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
