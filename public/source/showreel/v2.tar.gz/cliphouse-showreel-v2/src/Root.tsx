import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Showreel} from './videos/showreel/Showreel';
import {showreelMeta as meta} from './videos/showreel/meta';
import {showreelSchema as schema} from './videos/showreel/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="showreel" component={Showreel} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
