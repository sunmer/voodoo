import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Clay} from './videos/clay/Clay';
import {clayMeta as meta} from './videos/clay/meta';
import {claySchema as schema} from './videos/clay/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="clay" component={Clay} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
