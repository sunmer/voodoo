import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Tickets} from './videos/tickets/Tickets';
import {ticketsMeta as meta} from './videos/tickets/meta';
import {ticketsSchema as schema} from './videos/tickets/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="tickets" component={Tickets} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
