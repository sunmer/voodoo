import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Poll} from './videos/poll/Poll';
import {pollMeta as meta} from './videos/poll/meta';
import {pollSchema as schema} from './videos/poll/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="poll" component={Poll} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
