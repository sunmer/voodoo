import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Quotecard} from './videos/quotecard/Quotecard';
import {quotecardMeta as meta} from './videos/quotecard/meta';
import {quotecardSchema as schema} from './videos/quotecard/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="quotecard" component={Quotecard} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
