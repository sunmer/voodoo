import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Logo3d} from './videos/logo3d/Logo3d';
import {logo3dMeta as meta} from './videos/logo3d/meta';
import {logo3dSchema as schema} from './videos/logo3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="logo3d" component={Logo3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
