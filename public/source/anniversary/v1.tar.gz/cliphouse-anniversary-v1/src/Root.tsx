import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Anniversary} from './videos/anniversary/Anniversary';
import {anniversaryMeta as meta} from './videos/anniversary/meta';
import {anniversarySchema as schema} from './videos/anniversary/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="anniversary" component={Anniversary} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
