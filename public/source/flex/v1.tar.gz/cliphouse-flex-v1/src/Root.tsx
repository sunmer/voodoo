import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Flex} from './videos/flex/Flex';
import {flexMeta as meta} from './videos/flex/meta';
import {flexSchema as schema} from './videos/flex/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="flex" component={Flex} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
