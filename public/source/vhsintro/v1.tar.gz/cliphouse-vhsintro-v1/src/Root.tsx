import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Vhsintro} from './videos/vhsintro/Vhsintro';
import {vhsintroMeta as meta} from './videos/vhsintro/meta';
import {vhsintroSchema as schema} from './videos/vhsintro/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="vhsintro" component={Vhsintro} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
