import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Stack} from './videos/stack/Stack';
import {stackMeta as meta} from './videos/stack/meta';
import {stackSchema as schema} from './videos/stack/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="stack" component={Stack} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
