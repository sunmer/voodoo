import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Toplist} from './videos/toplist/Toplist';
import {toplistMeta as meta} from './videos/toplist/meta';
import {toplistSchema as schema} from './videos/toplist/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="toplist" component={Toplist} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
