import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Portraitcard} from './videos/portraitcard/Portraitcard';
import {portraitcardMeta as meta} from './videos/portraitcard/meta';
import {portraitcardSchema as schema} from './videos/portraitcard/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="portraitcard" component={Portraitcard} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
