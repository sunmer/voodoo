import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Gamingintro} from './videos/gamingintro/Gamingintro';
import {gamingintroMeta as meta} from './videos/gamingintro/meta';
import {gamingintroSchema as schema} from './videos/gamingintro/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="gamingintro" component={Gamingintro} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
