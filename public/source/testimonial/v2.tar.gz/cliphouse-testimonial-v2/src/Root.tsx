import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Testimonial} from './videos/testimonial/Testimonial';
import {testimonialMeta as meta} from './videos/testimonial/meta';
import {testimonialSchema as schema} from './videos/testimonial/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="testimonial" component={Testimonial} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
