import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Hiring} from './videos/hiring/Hiring';
import {hiringMeta as meta} from './videos/hiring/meta';
import {hiringSchema as schema} from './videos/hiring/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="hiring" component={Hiring} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
