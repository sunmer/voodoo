import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Iso3d} from './videos/iso3d/Iso3d';
import {iso3dMeta as meta} from './videos/iso3d/meta';
import {iso3dSchema as schema} from './videos/iso3d/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="iso3d" component={Iso3d} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
