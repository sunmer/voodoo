# Iso3d by cliphou.se, template v1

This is a standalone Remotion project for the cliphou.se `iso3d` template.

```bash
npm ci
npx remotion render src/index.ts iso3d out/video.mp4 --props=props.json
npx remotion studio src/index.ts
```

- Change text and colors in `props.json`. The schema is in `src/videos/iso3d/schema.ts`.
- Change layout, motion, and timing in `src/videos/iso3d/`. Scene timing is in `meta.ts`.
- Fonts come from pinned Fontsource packages. The template uses no network assets and no unseeded randomness.
- The same template version, dependency versions, and props render the same video.

The template is MIT-0: copy, modify, sell, and share it without attribution. Remotion has separate license terms: https://remotion.dev/license
