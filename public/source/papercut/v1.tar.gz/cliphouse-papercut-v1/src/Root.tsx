import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Papercut} from './videos/papercut/Papercut';
import {papercutMeta as meta} from './videos/papercut/meta';
import {papercutSchema as schema} from './videos/papercut/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="papercut" component={Papercut} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
