import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Birthday} from './videos/birthday/Birthday';
import {birthdayMeta as meta} from './videos/birthday/meta';
import {birthdaySchema as schema} from './videos/birthday/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="birthday" component={Birthday} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
