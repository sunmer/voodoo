declare module '*.woff2' {
  const url: string;
  export default url;
}
declare module '*.webp' {
  const url: string;
  export default url;
}
