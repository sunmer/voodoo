import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Photoquote} from './videos/photoquote/Photoquote';
import {photoquoteMeta as meta} from './videos/photoquote/meta';
import {photoquoteSchema as schema} from './videos/photoquote/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="photoquote" component={Photoquote} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
