import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Comingsoon} from './videos/comingsoon/Comingsoon';
import {comingsoonMeta as meta} from './videos/comingsoon/meta';
import {comingsoonSchema as schema} from './videos/comingsoon/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="comingsoon" component={Comingsoon} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
