import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Newyear} from './videos/newyear/Newyear';
import {newyearMeta as meta} from './videos/newyear/meta';
import {newyearSchema as schema} from './videos/newyear/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="newyear" component={Newyear} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
