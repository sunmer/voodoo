import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Cybermonday} from './videos/cybermonday/Cybermonday';
import {cybermondayMeta as meta} from './videos/cybermonday/meta';
import {cybermondaySchema as schema} from './videos/cybermonday/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="cybermonday" component={Cybermonday} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
