import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Subscribe} from './videos/subscribe/Subscribe';
import {subscribeMeta as meta} from './videos/subscribe/meta';
import {subscribeSchema as schema} from './videos/subscribe/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="subscribe" component={Subscribe} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
