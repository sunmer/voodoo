import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Slice} from './videos/slice/Slice';
import {sliceMeta as meta} from './videos/slice/meta';
import {sliceSchema as schema} from './videos/slice/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="slice" component={Slice} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
