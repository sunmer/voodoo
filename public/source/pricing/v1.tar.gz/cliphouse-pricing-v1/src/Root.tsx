import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Pricing} from './videos/pricing/Pricing';
import {pricingMeta as meta} from './videos/pricing/meta';
import {pricingSchema as schema} from './videos/pricing/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="pricing" component={Pricing} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
