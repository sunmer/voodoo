import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Flashsale} from './videos/flashsale/Flashsale';
import {flashsaleMeta as meta} from './videos/flashsale/meta';
import {flashsaleSchema as schema} from './videos/flashsale/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="flashsale" component={Flashsale} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
