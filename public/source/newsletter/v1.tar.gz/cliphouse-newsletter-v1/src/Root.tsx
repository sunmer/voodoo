import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Newsletter} from './videos/newsletter/Newsletter';
import {newsletterMeta as meta} from './videos/newsletter/meta';
import {newsletterSchema as schema} from './videos/newsletter/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="newsletter" component={Newsletter} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
