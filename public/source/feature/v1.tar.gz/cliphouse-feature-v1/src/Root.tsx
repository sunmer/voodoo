import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Feature} from './videos/feature/Feature';
import {featureMeta as meta} from './videos/feature/meta';
import {featureSchema as schema} from './videos/feature/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="feature" component={Feature} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
