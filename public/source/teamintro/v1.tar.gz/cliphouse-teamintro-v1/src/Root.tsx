import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Teamintro} from './videos/teamintro/Teamintro';
import {teamintroMeta as meta} from './videos/teamintro/meta';
import {teamintroSchema as schema} from './videos/teamintro/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="teamintro" component={Teamintro} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
