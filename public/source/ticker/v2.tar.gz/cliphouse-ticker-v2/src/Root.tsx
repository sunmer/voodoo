import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Ticker} from './videos/ticker/Ticker';
import {tickerMeta as meta} from './videos/ticker/meta';
import {tickerSchema as schema} from './videos/ticker/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="ticker" component={Ticker} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
