import React from 'react';
import {Composition} from 'remotion';
import props from '../props.json';
import {Announcement} from './videos/announcement/Announcement';
import {announcementMeta as meta} from './videos/announcement/meta';
import {announcementSchema as schema} from './videos/announcement/schema';

export const RemotionRoot: React.FC = () => (
  <Composition id="announcement" component={Announcement} schema={schema} defaultProps={props as never}
    width={meta.width} height={meta.height} fps={meta.fps} durationInFrames={meta.durationInFrames} />
);
